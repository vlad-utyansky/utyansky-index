/**
 * build_index.js — Генератор реестра слотов Индекса Утянского
 * Запуск: node scripts/build_index.js
 *
 * Сканирует src/ и capsules/, извлекает [IDX: XXXXX] и data-idx,
 * собирает UTYANSKY_INDEX_REGISTRY.json за O(n) по файлам.
 * Навигация по реестру — O(1) по слоту.
 */

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const SCAN_DIRS = ['src', 'capsules'];
const OUTPUT = path.join(ROOT, 'UTYANSKY_INDEX_REGISTRY.json');

const IDX_COMMENT = /\[IDX:\s*([0-9\-]+)\]/gi;
const IDX_ATTR = /data-idx="([0-9\-]+)"/gi;
const LOCK_ATTR = /data-lock="([0-9]+)"/i;
const MAX_LINES = 450;

function walk(dir) {
  const results = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      results.push(...walk(full));
    } else {
      results.push(full);
    }
  }
  return results;
}

function extract(text, file) {
  const ids = new Set();
  let m;
  const reComment = new RegExp(IDX_COMMENT);
  while ((m = reComment.exec(text)) !== null) ids.add(m[1]);
  const reAttr = new RegExp(IDX_ATTR);
  while ((m = reAttr.exec(text)) !== null) ids.add(m[1]);

  if (file && file.endsWith('.json')) {
    try {
      const js = JSON.parse(text);
      if (js && js._meta && js._meta.idx) ids.add(String(js._meta.idx));
    } catch(e) {}
  }
  return [...ids];
}

const registry = {};
const violations = [];

for (const sub of SCAN_DIRS) {
  const dir = path.join(ROOT, sub);
  if (!fs.existsSync(dir)) continue;
  for (const file of walk(dir)) {
    const text = fs.readFileSync(file, 'utf-8');
    const lines = text.split('\n').length;
    const rel = path.relative(ROOT, file);
    const ids = extract(text, file);
    const lockMatch = text.match(LOCK_ATTR);
    const hasJsonLock = text.includes('"lock": "00000"') || text.includes('"lock":"00000"');
    const isCapsule = path.basename(file).startsWith('00000-');

    for (const id of ids) {
      if (registry[id] && registry[id].file !== rel) {
        violations.push(`COLLISION: [IDX: ${id}] уже занят файлом ${registry[id].file}, конфликт с ${rel}`);
      } else {
        registry[id] = {
          file: rel,
          lines: lines,
          locked: (lockMatch ? lockMatch[1] === '00000' : false) || hasJsonLock,
          capsule: isCapsule,
        };
      }
    }

    if (lines > MAX_LINES) {
      violations.push(`LIMIT: ${rel} — ${lines} строк (лимит ${MAX_LINES}). Требуется декомпозиция.`);
    }
  }
}

fs.writeFileSync(OUTPUT, JSON.stringify(registry, null, 2));

if (violations.length > 0) {
  console.error('\\n=== Обнаружены нарушения ===');
  for (const v of violations) console.error('  ' + v);
  console.error(`\\nРеестр записан, но коммит будет заблокирован.\\n`);
  process.exit(1);
} else {
  const count = Object.keys(registry).length;
  console.log(`\\nРеестр собран: ${count} слотов в ${OUTPUT}\\n`);
  for (const [id, info] of Object.entries(registry)) {
    const tag = info.capsule ? '[CAPSULE]' : '[WORK]  ';
    const lock = info.locked ? ' [LOCKED]' : '';
    console.log(`  ${tag} [IDX: ${id}] — ${info.file} (${info.lines} строк)${lock}`);
  }
  console.log();
}
