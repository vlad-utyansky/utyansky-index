// [IDX: 90300] Скрипт телеметрии и метрик качества
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const SRC_DIR = path.join(ROOT, 'src');
const CAPSULES_DIR = path.join(ROOT, 'capsules');
const PIPELINE_LOG = path.join(ROOT, 'pipeline_log.json');

const LIMIT_HEALTHY = 400;
const LIMIT_WARNING = 450;

// --- CHI: Codebase Health Index ---
function countLines(filePath) {
  return fs.readFileSync(filePath, 'utf-8').split('\n').length;
}

function scanCodebase() {
  const dirs = [SRC_DIR, CAPSULES_DIR];
  const stats = { healthy: 0, warning: 0, critical: 0, total: 0, files: [] };

  for (const dir of dirs) {
    if (!fs.existsSync(dir)) continue;
    const files = fs.readdirSync(dir).filter(f =>
      f.endsWith('.js') || f.endsWith('.jsx') || f.endsWith('.json') || f.endsWith('.py')
    );
    for (const file of files) {
      const full = path.join(dir, file);
      const lines = countLines(full);
      stats.total++;
      let zone;
      if (lines <= LIMIT_HEALTHY) { stats.healthy++; zone = 'healthy'; }
      else if (lines <= LIMIT_WARNING) { stats.warning++; zone = 'warning'; }
      else { stats.critical++; zone = 'critical'; }
      stats.files.push({ file: path.relative(ROOT, full), lines, zone });
    }
  }

  const chi = stats.total > 0 ? (stats.healthy / stats.total) * 100 : 100;
  return { chi: Math.round(chi * 10) / 10, ...stats };
}

// --- RFR: Rollback / Failure Rate ---
function calcRFR() {
  if (!fs.existsSync(PIPELINE_LOG)) {
    return { rfr: 0, total: 0, passed: 0, failed: 0, note: 'pipeline_log.json not found' };
  }
  try {
    const log = JSON.parse(fs.readFileSync(PIPELINE_LOG, 'utf-8'));
    const entries = Array.isArray(log) ? log : (log.entries || []);
    let passed = 0, failed = 0;
    for (const e of entries) {
      if (e.verdict === 'pass' || e.status === 'done') passed++;
      else if (e.verdict === 'fail' || e.status === 'error') failed++;
    }
    const total = passed + failed;
    const rfr = total > 0 ? Math.round((failed / total) * 100 * 10) / 10 : 0;
    return { rfr, total, passed, failed };
  } catch(e) {
    return { rfr: 0, total: 0, passed: 0, failed: 0 };
  }
}

// --- CRS: Context Retention Score ---
function calcCRS() {
  if (!fs.existsSync(PIPELINE_LOG)) {
    return { crs: 1.0, samples: 0, note: 'pipeline_log.json not found' };
  }
  try {
    const log = JSON.parse(fs.readFileSync(PIPELINE_LOG, 'utf-8'));
    const entries = Array.isArray(log) ? log : (log.entries || []);
    const checks = entries.filter(e => e.verdict !== undefined);
    if (checks.length === 0) return { crs: 1.0, samples: 0 };

    const weights = { slot: 0.3, locks: 0.3, lines: 0.2, logic: 0.2 };
    let totalScore = 0;
    for (const c of checks) {
      let score = 0;
      if (c.checks) {
        if (c.checks.slot_ok) score += weights.slot;
        if (c.checks.locks_ok) score += weights.locks;
        if (c.checks.lines_ok) score += weights.lines;
        if (c.checks.logic_ok) score += weights.logic;
      } else {
        score = c.verdict === 'pass' ? 1.0 : 0.4;
      }
      totalScore += score;
    }
    const crs = Math.round((totalScore / checks.length) * 100) / 100;
    return { crs, samples: checks.length };
  } catch(e) {
    return { crs: 1.0, samples: 0 };
  }
}

// --- Сборка отчёта ---
function generateReport() {
  const chi = scanCodebase();
  const rfr = calcRFR();
  const crs = calcCRS();

  const report = {
    timestamp: new Date().toISOString(),
    metrics: {
      context_retention_score: crs.crs,
      rollback_failure_rate: rfr.rfr,
      codebase_health_index: chi.chi,
    },
    details: {
      crs: crs,
      rfr: rfr,
      chi: {
        chi: chi.chi,
        healthy: chi.healthy,
        warning: chi.warning,
        critical: chi.critical,
        total: chi.total,
        files: chi.files,
      },
    },
    verdict: {
      crs: crs.crs >= 0.9 ? 'ok' : crs.crs >= 0.7 ? 'drift' : 'critical',
      rfr: rfr.rfr <= 10 ? 'ok' : rfr.rfr <= 25 ? 'warning' : 'critical',
      chi: chi.chi >= 90 ? 'ok' : chi.chi >= 70 ? 'warning' : 'critical',
    },
  };

  const outPath = path.join(ROOT, 'telemetry_report.json');
  fs.writeFileSync(outPath, JSON.stringify(report, null, 2));
  return report;
}

// --- Запуск ---
const report = generateReport();
console.log('=== Utyansky Index Telemetry ===');
console.log(`Timestamp:           ${report.timestamp}`);
console.log(`Context Retention:   ${report.metrics.context_retention_score}  [${report.verdict.crs}]`);
console.log(`Rollback Rate:       ${report.metrics.rollback_failure_rate}%  [${report.verdict.rfr}]`);
console.log(`Codebase Health:     ${report.metrics.codebase_health_index}%  [${report.verdict.chi}]`);
console.log(`Files: ${report.details.chi.healthy} healthy / ${report.details.chi.warning} warning / ${report.details.chi.critical} critical`);
console.log(`Report saved: telemetry_report.json`);
