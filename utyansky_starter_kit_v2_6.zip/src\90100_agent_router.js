// [IDX: 90100] Маршрутизатор задач между агентами
const fs = require('fs');
const path = require('path');

const AGENT_PROMPTS = {
  planner:   'capsules/00000-70000-00001_agent_planner_prompt.json',
  coder:     'capsules/00000-70000-00002_agent_coder_prompt.json',
  validator: 'capsules/00000-70000-00003_agent_validator_prompt.json',
};

// Загрузка системного промпта агента из капсулы
function loadAgentPrompt(agentClass) {
  const file = AGENT_PROMPTS[agentClass];
  if (!file) throw new Error(`Unknown agent class: ${agentClass}`);
  const raw = JSON.parse(fs.readFileSync(path.resolve(__dirname, '..', file), 'utf-8'));
  if (raw._meta.lock !== '00000') throw new Error(`Capsule lock broken: ${file}`);
  return raw.system_prompt;
}

// Загрузка содержимого целевого слота (не всего файла, а блока по IDX)
function loadSlotContent(filePath, slotIdx) {
  const fullPath = path.resolve(__dirname, '..', filePath);
  if (!fs.existsSync(fullPath)) throw new Error(`File ${filePath} not found`);
  const content = fs.readFileSync(fullPath, 'utf-8');
  const lines = content.split('\n');
  const start = lines.findIndex(l => l.includes(`[IDX: ${slotIdx}]`) || l.includes(`data-idx="${slotIdx}"`));
  if (start === -1) throw new Error(`Slot ${slotIdx} not found in ${filePath}`);
  
  // Блок до следующего слота или до конца файла
  const slotHeaderRe = /\[IDX:\s*[0-9\-]+\]|data-idx="[0-9\-]+"/;
  let end = lines.findIndex((l, i) => i > start && slotHeaderRe.test(l));
  if (end === -1) end = lines.length;
  return lines.slice(start, end).join('\n');
}

// Маршрутизация: собрать контекст для агента
function routeToAgent(agentClass, task) {
  const systemPrompt = loadAgentPrompt(agentClass);
  let userContext = '';

  if (agentClass === 'planner') {
    userContext = task.description;
  } else if (agentClass === 'coder') {
    userContext = loadSlotContent(task.file, task.slot);
  } else if (agentClass === 'validator') {
    userContext = loadSlotContent(task.file, task.slot);
  }

  return { systemPrompt, userContext, task };
}

module.exports = { routeToAgent, loadAgentPrompt, loadSlotContent };
