# 🏛️ Индекс Утянского v2.6

**Открытый архитектурный стандарт для безопасного вайбкодинга и мультиагентных систем ИИ**

> *Code talks, bullshit walks.* Стандарт доказывается в боевом коде и на реальных нагрузках.

![License: MIT](https://img.shields.io/badge/License-MIT-blue)
![Version: v2.6](https://img.shields.io/badge/Version-v2.6-green)
![Status: Open Standard](https://img.shields.io/badge/Status-Open_Standard-orange)
![Language: JS / Python](https://img.shields.io/badge/Lang-JS%20%2F%20Python-yellow)

---

## 📌 Оглавление

1. [Проблема: деградация контекста при вайбкодинге](#-проблема-деградация-контекста-при-вайбкодинге)
2. [Три Закона Индекса Утянского](#-три-закона-индекса-утянского)
3. [Быстрый старт и структура Starter Kit](#-быстрый-старт-и-структура-starter-kit)
4. [Мультиагентная архитектура](#-мультиагентная-архитектура)
5. [Метрики качества и телеметрия](#-метрики-качества-и-телеметрия)
6. [Практический пример декомпозиции](#-практический-пример-декомпозиции)
7. [FAQ](#-faq)

---

## 🛑 Проблема: деградация контекста при вайбкодинге

Когда вы работаете с LLM над кодовой базой, модель неизбежно сталкивается с двумя физическими ограничениями:

**1. Lost-in-the-Middle** — в длинных файлах и промптах модель хуже удерживает внимание к деталям в середине. Это не баг конкретной нейросети, а свойство архитектуры трансформеров. Чем больше контекст — тем выше шанс, что модель «забудет» часть инструкций и сгенерирует неточность.

**2. Паразитные правки** — попросив ИИ «поменять цвет кнопки», вы рискуете получить переписанный файл на 800 строк, где заодно сломана бизнес-логика. Модель не всегда различает «что я должен трогать» от «что я трогать не должен».

Обе проблемы усугубляются с ростом проекта: больше файлов, больше зависимостей, больше шансов, что точечная правка ломает соседний код.

---

## 🛡️ Три Закона Индекса Утянского

### Закон 1. Предел Чистого Контекста — 4 листа А4

Любой рабочий файл или системный промпт — **не более ~350–400 строк** (~3000 токенов). Это не магическое число, а эмпирический ориентир: в этих пределах модель удерживает контекст без существенной деградации внимания.

Если файл растёт — **обязательная декомпозиция**: выносим логически завершённый блок в отдельный подкомпонент. Не «рекомендуется», а «обязательно» — это проверяется скриптом-стражем на pre-commit.

### Закон 2. Числовая индексация слотов [IDX: XXXXX]

Каждому функциональному элементу присваивается пятизначный числовой адрес `[IDX: XXXXX]`:

| Диапазон | Назначение |
|---|---|
| `00000` | Неприкасаемые капсулы (замок Zero-Trust) |
| `10000–19999` | UI, верстка, визуальные редакторы |
| `20000–29999` | Рабочие холсты, контент-завод |
| `30000–39999` | Финансовый контур, эквайринг |
| `70000–79999` | Аналитика, мультиагенты |
| `90000–99999` | Инфраструктура, оркестрация, стражи |

Модель получает **прямой адрес** нужного слота и правит только его — без сканирования всей кодовой базы. Поиск за O(1) через реестр `UTYANSKY_INDEX_REGISTRY.json`, который генерируется автоматически.

### Закон 3. Zero-Trust замок [IDX: 00000]

Отлаженные блоки помечаются замком:

```html
<!-- [IDX: 71390] [IDX: 00000] -->
<div data-idx="71390" data-lock="00000" data-desc="Графики аналитики">
  ...содержимое под защитой...
</div>
```

Модель не трогает блоки с `data-lock="00000"`. Правки вносятся только в слот, явно указанный в запросе разработчика.

Критическое ядро (системные промпты, финансовые формулы, крипто-алгоритмы) выносится в отдельные файлы с префиксом `00000-`:

```
00000-70000-00001_analytics_prompt.json   — капсула промпта
00000-30000-00001_payment_core.py         — неприкасаемое ядро
```

Эти файлы физически отделены от верстки — при правках интерфейса они не открываются и не затираются.

---

## 🚀 Быстрый старт и структура Starter Kit

### Структура проекта

```
utyansky-starter-kit/
  src/
    10000_app.jsx                  ← корневой оркестратор (замок 00000)
    10100_widget.jsx                ← рабочий UI-компонент (без замка)
  capsules/
    00000-30000-00001_core.json     ← капсула критического ядра
  scripts/
    build_index.js                  ← генератор реестра слотов
    guard_utyansky_slots.py         ← страж архитектуры
    telemetry_benchmark.js          ← метрики и телеметрия
  hooks/
    pre-commit                      ← git hook
  README.md                         ← этот файл
```

### Установка за 5 минут

```bash
git init
cp hooks/pre-commit .git/hooks/pre-commit
chmod +x .git/hooks/pre-commit
python scripts/guard_utyansky_slots.py   # проверка
node scripts/build_index.js              # реестр слотов
node scripts/telemetry_benchmark.js      # метрики
```

### Шаблон корневого оркестратора — `src/10000_app.jsx`

```jsx
// [IDX: 10000] Корневой оркестратор приложения
import { Widget } from './10100_widget.jsx';
import { CORE } from '../capsules/00000-30000-00001_core.json';

export function App() {
  return (
    <div data-idx="10000" data-lock="00000" data-desc="Корневое приложение">
      <Widget config={CORE.config} />
    </div>
  );
}
```

### Шаблон рабочего компонента — `src/10100_widget.jsx`

```jsx
// [IDX: 10100] Рабочий UI-компонент
export function Widget({ config }) {
  return (
    <div data-idx="10100" data-desc="Виджет">
      {/* Содержимое виджета. Замка нет — ИИ может править по запросу. */}
    </div>
  );
}
```

### Шаблон капсулы ядра — `capsules/00000-30000-00001_core.json`

```json
{
  "_meta": {
    "idx": "00000-30000-00001",
    "lock": "00000",
    "desc": "Капсула критического ядра — правка запрещена"
  },
  "config": {
    "version": "2.6",
    "mode": "production"
  }
}
```

### Скрипт-страж — `scripts/guard_utyansky_slots.py`

```python
#!/usr/bin/env python3
"""Страж архитектуры Индекса Утянского.
Проверяет: синтаксис IDX, лимит строк, коллизии, замки."""

import os, re, sys

SRC_DIR = os.path.join(os.path.dirname(__file__), '..', 'src')
CAPSULES_DIR = os.path.join(os.path.dirname(__file__), '..', 'capsules')
MAX_LINES = 450
IDX_PATTERN = re.compile(r'\[IDX:\s*([\d-]+)\s*\]')
DATA_IDX = re.compile(r'data-idx="([\d-]+)"')

errors = []
slots = {}

def scan_dir(d, label):
    if not os.path.exists(d):
        return
    for f in sorted(os.listdir(d)):
        if not f.endswith(('.js', '.jsx', '.json', '.py')):
            continue
        path = os.path.join(d, f)
        with open(path, encoding='utf-8') as fh:
            lines = fh.readlines()
        if len(lines) > MAX_LINES:
            errors.append(f'{label}: {f} - {len(lines)} lines > {MAX_LINES}')
        content = ''.join(lines)
        is_capsule = f.startswith('00000-')
        if is_capsule and '"lock": "00000"' not in content:
            errors.append(f'CAPSULE: {f} - no lock 00000')
        for m in IDX_PATTERN.finditer(content):
            idx = m.group(1)
            if idx == '00000':
                continue
            if idx in slots:
                errors.append(f'COLLISION: IDX {idx} in {f} and {slots[idx]}')
            else:
                slots[idx] = f
        for m in DATA_IDX.finditer(content):
            idx = m.group(1)
            if idx in slots and slots[idx] != f:
                errors.append(f'COLLISION: data-idx {idx} in {f} and {slots[idx]}')
            else:
                slots[idx] = f

scan_dir(SRC_DIR, 'SRC')
scan_dir(CAPSULES_DIR, 'CAPSULE')

if errors:
    print(f'Guard: FAIL - {len(errors)} issue(s):')
    for e in errors:
        print(f'  x {e}')
    sys.exit(1)
else:
    print(f'Guard: OK. {len(slots)} slots, no violations.')
    for idx, f in sorted(slots.items()):
        print(f'  [IDX: {idx}] - {f}')
```

### Генератор реестра — `scripts/build_index.js`

```javascript
// [IDX: 90100] Генератор реестра слотов UTYANSKY_INDEX_REGISTRY.json
const fs = require('fs');
const path = require('path');

const SRC_DIR = path.resolve(__dirname, '../src');
const CAPSULES_DIR = path.resolve(__dirname, '../capsules');
const OUT = path.resolve(__dirname, '../UTYANSKY_INDEX_REGISTRY.json');

const IDX_RE = /\[IDX:\s*([\d-]+)\s*\]/g;
const DATA_IDX_RE = /data-idx="([\d-]+)"/g;

function scanDir(dir, label) {
  const entries = [];
  if (!fs.existsSync(dir)) return entries;
  for (const f of fs.readdirSync(dir)) {
    if (!f.match(/\.(js|jsx|json|py)$/)) continue;
    const full = path.join(dir, f);
    const content = fs.readFileSync(full, 'utf-8');
    const lines = content.split('\n').length;
    const idxs = new Set();
    let m;
    while ((m = IDX_RE.exec(content))) idxs.add(m[1]);
    while ((m = DATA_IDX_RE.exec(content))) idxs.add(m[1]);
    const isCapsule = f.startsWith('00000-');
    const hasLock = content.includes('data-lock="00000"') || content.includes('"lock": "00000"');
    for (const idx of idxs) {
      entries.push({ idx, file: `${label}/${f}`, lines, locked: isCapsule || hasLock, type: isCapsule ? 'capsule' : 'work' });
    }
  }
  return entries;
}

const entries = [...scanDir(SRC_DIR, 'src'), ...scanDir(CAPSULES_DIR, 'capsules')];
const seen = {};
const collisions = [];
for (const e of entries) {
  if (e.idx === '00000') continue;
  if (seen[e.idx]) collisions.push(`${e.idx}: ${e.file} and ${seen[e.idx]}`);
  else seen[e.idx] = e.file;
}

const registry = {
  generated: new Date().toISOString(),
  total_slots: entries.filter(e => e.idx !== '00000').length,
  collisions,
  entries,
};

fs.writeFileSync(OUT, JSON.stringify(registry, null, 2));
console.log(`Build: ${registry.total_slots} slots, ${collisions.length} collisions.`);
if (collisions.length) { collisions.forEach(c => console.error('  ' + c)); process.exit(1); }
```

### Git hook — `hooks/pre-commit`

```bash
#!/bin/bash
echo "=== Utyansky Guard: pre-commit ==="
python scripts/guard_utyansky_slots.py || exit 1
node scripts/build_index.js || exit 1
echo "=== OK ==="
```

---

## 🤖 Мультиагентная архитектура

### Пайплайн: Планировщик → Исполнитель → Валидатор

```
ТЗ разработчика
      |
Маршрутизатор [90100] -> Планировщик [70100]
      |                     |
      |              план: [{slot, action, file}, ...]
      |                     |
      |        для каждой задачи:
      |                     |
      |           Исполнитель [70200] -> правит слот
      |                     |
      |           Валидатор  [90200] -> проверяет
      |                     |
      |              pass -> следующая задача
      |              fail -> стоп, откат
      |
  Результаты пайплайна -> pipeline_log.json
```

Каждый агент получает **только свой системный промпт из капсулы + содержимое одного слота** — не весь файл, не весь проект. Контекст каждого агента — в пределах закона А4.

### Структура файлов

```
capsules/
  00000-70000-00001_agent_planner_prompt.json
  00000-70000-00002_agent_coder_prompt.json
  00000-70000-00003_agent_validator_prompt.json

src/
  90100_agent_router.js
  90200_agent_pipeline.js
```

### Капсула промпта Планировщика

```json
{
  "_meta": {
    "idx": "00000-70000-00001",
    "lock": "00000",
    "desc": "Системный промпт Агента-Планировщика — правка запрещена",
    "agent_class": "planner",
    "agent_idx": "70100"
  },
  "system_prompt": "Ты — Агент-Планировщик [IDX: 70100]. Твоя задача: получить ТЗ и разбить его на атомарные задачи для Агента-Исполнителя [IDX: 70200].

Правила:
1. Каждая задача — один слот [IDX: XXXXX], одна правка, один файл.
2. Не объединяй несколько правок в одну задачу.
3. Указывай целевой слот, действие и ожидаемый результат.
4. Не пиши код — только план.

Формат ответа:
[{"slot": "IDX", "action": "описание", "file": "путь", "expect": "результат"}]"
}
```

### Капсула промпта Исполнителя

```json
{
  "_meta": {
    "idx": "00000-70000-00002",
    "lock": "00000",
    "desc": "Системный промпт Агента-Исполнителя — правка запрещена",
    "agent_class": "coder",
    "agent_idx": "70200"
  },
  "system_prompt": "Ты — Агент-Исполнитель [IDX: 70200]. Твоя задача: получить одну атомарную задачу от Планировщика и выполнить её.

Правила:
1. Работай строго в указанном слоте [IDX: XXXXX].
2. Не трогай блоки с data-lock="00000".
3. Не открывай файлы с префиксом 00000-.
4. Верни результат и diff изменённых строк.

Формат ответа:
{"slot": "IDX", "status": "done|error", "diff": "изменённые строки", "note": "комментарий"}"
}
```

### Капсула промпта Валидатора

```json
{
  "_meta": {
    "idx": "00000-70000-00003",
    "lock": "00000",
    "desc": "Системный промпт Стража-Валидатора — правка запрещена",
    "agent_class": "validator",
    "agent_idx": "90200"
  },
  "system_prompt": "Ты — Страж-Валидатор [IDX: 90200]. Твоя задача: проверить результат Агента-Исполнителя [IDX: 70200].

Проверяй:
1. Замки 00000 не тронуты.
2. Правка только в целевом слоте.
3. Лимит строк файла не превышен (<=450).
4. Синтаксис IDX не нарушен (только цифры и тире).

Формат ответа:
{"slot": "IDX", "verdict": "pass|fail", "issues": ["список проблем"]}"
}
```

### Маршрутизатор — `src/90100_agent_router.js`

```javascript
// [IDX: 90100] Маршрутизатор задач между агентами
const fs = require('fs');
const path = require('path');

const AGENT_PROMPTS = {
  planner:   'capsules/00000-70000-00001_agent_planner_prompt.json',
  coder:     'capsules/00000-70000-00002_agent_coder_prompt.json',
  validator: 'capsules/00000-70000-00003_agent_validator_prompt.json',
};

function loadAgentPrompt(agentClass) {
  const file = AGENT_PROMPTS[agentClass];
  if (!file) throw new Error('Unknown agent class: ' + agentClass);
  const raw = JSON.parse(fs.readFileSync(path.resolve(file), 'utf-8'));
  if (raw._meta.lock !== '00000') throw new Error('Capsule lock broken: ' + file);
  return raw.system_prompt;
}

function loadSlotContent(filePath, slotIdx) {
  const content = fs.readFileSync(path.resolve(filePath), 'utf-8');
  const lines = content.split('\n');
  const start = lines.findIndex(l => l.includes('[IDX: ' + slotIdx + ']'));
  if (start === -1) throw new Error('Slot ' + slotIdx + ' not found in ' + filePath);
  let end = lines.findIndex((l, i) => i > start && l.includes('[IDX:'));
  if (end === -1) end = lines.length;
  return lines.slice(start, end).join('\n');
}

function routeToAgent(agentClass, task) {
  const systemPrompt = loadAgentPrompt(agentClass);
  let userContext = '';
  if (agentClass === 'planner') {
    userContext = task.description;
  } else if (agentClass === 'coder' || agentClass === 'validator') {
    userContext = loadSlotContent(task.file, task.slot);
  }
  return { systemPrompt, userContext, task };
}

module.exports = { routeToAgent, loadAgentPrompt, loadSlotContent };
```

### Оркестратор пайплайна — `src/90200_agent_pipeline.js`

```javascript
// [IDX: 90200] Оркестратор пайплайна: Планировщик -> Исполнитель -> Валидатор
const { routeToAgent } = require('./90100_agent_router.js');
const fs = require('fs');
const path = require('path');

const LOG_PATH = path.resolve(__dirname, '..', 'pipeline_log.json');

async function callLLM(systemPrompt, userContext) {
  // Здесь — вызов вашей LLM
  return JSON.parse('{}');
}

function logEntry(entry) {
  let log = [];
  if (fs.existsSync(LOG_PATH)) {
    log = JSON.parse(fs.readFileSync(LOG_PATH, 'utf-8'));
    if (!Array.isArray(log)) log = log.entries || [];
  }
  log.push(entry);
  fs.writeFileSync(LOG_PATH, JSON.stringify(log, null, 2));
}

async function runPipeline(taskDescription) {
  const results = [];

  // 1. Планировщик
  const plannerCtx = routeToAgent('planner', { description: taskDescription });
  const plan = await callLLM(plannerCtx.systemPrompt, plannerCtx.userContext);
  results.push({ agent: 'planner', idx: '70100', output: plan });

  // 2. Для каждой задачи — Исполнитель -> Валидатор
  for (const task of plan) {
    const coderCtx = routeToAgent('coder', { file: task.file, slot: task.slot });
    const codeResult = await callLLM(coderCtx.systemPrompt, coderCtx.userContext);
    results.push({ agent: 'coder', idx: '70200', slot: task.slot, output: codeResult });

    const validatorCtx = routeToAgent('validator', { file: task.file, slot: task.slot });
    const verdict = await callLLM(validatorCtx.systemPrompt, validatorCtx.userContext);
    results.push({ agent: 'validator', idx: '90200', slot: task.slot, output: verdict });

    logEntry({
      slot: task.slot,
      verdict: verdict.verdict || 'pass',
      checks: verdict.checks || null,
      timestamp: new Date().toISOString(),
    });

    if (verdict.verdict === 'fail') {
      results.push({ status: 'pipeline_stopped', reason: 'Slot ' + task.slot + ' failed' });
      break;
    }
  }

  return results;
}

module.exports = { runPipeline };
```

### Сводка мультиагентного модуля

| Компонент | IDX | Файл | Роль |
|---|---|---|---|
| Планировщик | 70100 | капсула-промпт | Разбивает ТЗ на атомарные задачи |
| Исполнитель | 70200 | капсула-промпт | Выполняет одну задачу в одном слоте |
| Валидатор | 90200 | капсула-промпт | Проверяет результат перед коммитом |
| Маршрутизатор | 90100 | `90100_agent_router.js` | Загружает промпт из капсулы, отдаёт слот |
| Пайплайн | 90200 | `90200_agent_pipeline.js` | Связывает агенты в цепочку |

---

## 📊 Метрики качества и телеметрия

### Принцип

Стандарт без измерений — это мнение. Метрики ниже дают объективную картину: держит ли контекст, как часто страж бракует правки, и не пора ли декомпозировать файлы.

### 1. Context Retention Score (CRS)

**Что измеряет:** насколько результат ИИ соответствует исходной задаче.

| Пункт проверки | Вес |
|---|---|
| Правка только в целевом слоте | 0.3 |
| Замки 00000 не тронуты | 0.3 |
| Лимит строк не превышен | 0.2 |
| Логическая целостность | 0.2 |

**Формула:** \( 	ext{CRS} = \sum w_i 	imes p_i \), где \( w_i \) — вес, \( p_i \in \{0, 1\} \).

| Зона | CRS | Интерпретация |
|---|---|---|
| 🟢 | ≥ 0.9 | Контекст держится |
| 🟡 | 0.7–0.9 | Лёгкий дрейф, проверить промпт |
| 🔴 | < 0.7 | Контекст поплыл, декомпозиция |

### 2. Rollback / Failure Rate (RFR)

**Что измеряет:** процент задач, заблокированных Валидатором.

**Формула:** \( 	ext{RFR} = rac{N_{	ext{fail}}}{N_{	ext{total}}} 	imes 100\% \)

| Зона | RFR | Интерпретация |
|---|---|---|
| 🟢 | ≤ 10% | Норма |
| 🟡 | 10–25% | Агенты промахиваются |
| 🔴 | > 25% | Деградация контекста |

### 3. Codebase Health Index (CHI)

**Что измеряет:** процент файлов в пределах лимита 4 листов А4.

| Зона | Строк | Статус |
|---|---|---|
| 🟢 healthy | ≤ 400 | Норма |
| 🟡 warning | 401–450 | Буфер стража |
| 🔴 critical | > 450 | Декомпозиция |

**Формула:** \( 	ext{CHI} = rac{N_{	ext{healthy}}}{N_{	ext{total}}} 	imes 100\% \)

| Зона | CHI | Интерпретация |
|---|---|---|
| 🟢 | ≥ 90% | Кодовая база в форме |
| 🟡 | 70–90% | Есть «толстые» файлы |
| 🔴 | < 70% | Декомпозиция срочна |

### Скрипт телеметрии — `scripts/telemetry_benchmark.js`

```javascript
// [IDX: 90300] Скрипт телеметрии и метрик
const fs = require('fs');
const path = require('path');

const SRC_DIR = path.resolve(__dirname, '../src');
const CAPSULES_DIR = path.resolve(__dirname, '../capsules');
const PIPELINE_LOG = path.resolve(__dirname, '../pipeline_log.json');
const LIMIT_HEALTHY = 400;
const LIMIT_WARNING = 450;

function countLines(filePath) {
  return fs.readFileSync(filePath, 'utf-8').split('\n').length;
}

function scanCodebase() {
  const dirs = [SRC_DIR, CAPSULES_DIR];
  const stats = { healthy: 0, warning: 0, critical: 0, total: 0, files: [] };
  for (const dir of dirs) {
    if (!fs.existsSync(dir)) continue;
    const files = fs.readdirSync(dir).filter(f =>
      f.endsWith('.js') || f.endsWith('.jsx') || f.endsWith('.json') || f.endsWith('.py')
    );
    for (const file of files) {
      const full = path.join(dir, file);
      const lines = countLines(full);
      stats.total++;
      let zone;
      if (lines <= LIMIT_HEALTHY) { stats.healthy++; zone = 'healthy'; }
      else if (lines <= LIMIT_WARNING) { stats.warning++; zone = 'warning'; }
      else { stats.critical++; zone = 'critical'; }
      stats.files.push({ file, lines, zone });
    }
  }
  const chi = stats.total > 0 ? (stats.healthy / stats.total) * 100 : 100;
  return { chi: Math.round(chi * 10) / 10, ...stats };
}

function calcRFR() {
  if (!fs.existsSync(PIPELINE_LOG)) return { rfr: 0, total: 0, passed: 0, failed: 0 };
  const log = JSON.parse(fs.readFileSync(PIPELINE_LOG, 'utf-8'));
  const entries = Array.isArray(log) ? log : (log.entries || []);
  let passed = 0, failed = 0;
  for (const e of entries) {
    if (e.verdict === 'pass' || e.status === 'done') passed++;
    else if (e.verdict === 'fail' || e.status === 'error') failed++;
  }
  const total = passed + failed;
  const rfr = total > 0 ? Math.round((failed / total) * 100 * 10) / 10 : 0;
  return { rfr, total, passed, failed };
}

function calcCRS() {
  if (!fs.existsSync(PIPELINE_LOG)) return { crs: 1.0, samples: 0 };
  const log = JSON.parse(fs.readFileSync(PIPELINE_LOG, 'utf-8'));
  const entries = Array.isArray(log) ? log : (log.entries || []);
  const checks = entries.filter(e => e.verdict !== undefined);
  if (checks.length === 0) return { crs: 1.0, samples: 0 };
  const weights = { slot: 0.3, locks: 0.3, lines: 0.2, logic: 0.2 };
  let totalScore = 0;
  for (const c of checks) {
    let score = 0;
    if (c.checks) {
      if (c.checks.slot_ok) score += weights.slot;
      if (c.checks.locks_ok) score += weights.locks;
      if (c.checks.lines_ok) score += weights.lines;
      if (c.checks.logic_ok) score += weights.logic;
    } else {
      score = c.verdict === 'pass' ? 1.0 : 0.4;
    }
    totalScore += score;
  }
  const crs = Math.round((totalScore / checks.length) * 100) / 100;
  return { crs, samples: checks.length };
}

function generateReport() {
  const chi = scanCodebase();
  const rfr = calcRFR();
  const crs = calcCRS();
  const report = {
    timestamp: new Date().toISOString(),
    metrics: {
      context_retention_score: crs.crs,
      rollback_failure_rate: rfr.rfr,
      codebase_health_index: chi.chi,
    },
    details: { crs, rfr, chi },
    verdict: {
      crs: crs.crs >= 0.9 ? 'ok' : crs.crs >= 0.7 ? 'drift' : 'critical',
      rfr: rfr.rfr <= 10 ? 'ok' : rfr.rfr <= 25 ? 'warning' : 'critical',
      chi: chi.chi >= 90 ? 'ok' : chi.chi >= 70 ? 'warning' : 'critical',
    },
  };
  const outPath = path.resolve(__dirname, '../telemetry_report.json');
  fs.writeFileSync(outPath, JSON.stringify(report, null, 2));
  return report;
}

const report = generateReport();
console.log('=== Utyansky Index Telemetry ===');
console.log('Timestamp:           ' + report.timestamp);
console.log('Context Retention:   ' + report.metrics.context_retention_score + '  [' + report.verdict.crs + ']');
console.log('Rollback Rate:       ' + report.metrics.rollback_failure_rate + '%  [' + report.verdict.rfr + ']');
console.log('Codebase Health:     ' + report.metrics.codebase_health_index + '%  [' + report.verdict.chi + ']');
console.log('Files: ' + report.details.chi.healthy + ' healthy / ' + report.details.chi.warning + ' warning / ' + report.details.chi.critical + ' critical');
console.log('Report saved: telemetry_report.json');
```

### Интеграция в pipeline

```
Маршрутизатор [90100]
      |
Планировщик [70100] -> Исполнитель [70200] -> Валидатор [90200]
                                              |
                                    запись в pipeline_log.json
                                              |
                                    Телеметрия [90300] -> telemetry_report.json
                                              |
                                    CI/CD: блокировка релиза при verdict = "critical"
```

---

## 🔨 Практический пример декомпозиции

### До: один файл на 1200 строк

```
src/
  dashboard.jsx          <-- 1200 строк
```

Вёрстка шапки, логика графиков, форма оплаты, обработчики событий, финансовые формулы — всё в одном. ИИ при любой правке читает 1200 строк, теряет середину, рискует задеть чужую логику.

### После: четыре файла + капсула

```
src/
  10100_dashboard.jsx              <-- 80 строк (оркестратор)
  10200_dashboard_charts.jsx       <-- 310 строк (графики)
  10300_dashboard_payment.jsx      <-- 280 строк (форма оплаты)
  10400_dashboard_events.jsx       <-- 220 строк (обработчики)

capsules/
  00000-10300-00001_payment_math.json   <-- 90 строк (капсула)
```

### Что внутри

**`10100_dashboard.jsx` — оркестратор (80 строк)**

```jsx
// [IDX: 10100] Оркестратор дашборда
import { Charts } from './10200_dashboard_charts.jsx';
import { PaymentForm } from './10300_dashboard_payment.jsx';
import { useDashboardEvents } from './10400_dashboard_events.jsx';
import { PAYMENT_RATES } from '../capsules/00000-10300-00001_payment_math.json';

export function Dashboard() {
  const events = useDashboardEvents(PAYMENT_RATES);
  return (
    <div data-idx="10100" data-lock="00000" data-desc="Корневой дашборд">
      <Charts data={events.chartData} />
      <PaymentForm onSubmit={events.handlePayment} />
    </div>
  );
}
```

Оркестратор только собирает компоненты и прокидывает данные. Замок `00000` на корневом контейнере.

**`10200_dashboard_charts.jsx` — графики (310 строк)**

```jsx
// [IDX: 10200] Модуль графиков дашборда
export function Charts({ data }) {
  return (
    <div data-idx="10200" data-desc="Блок графиков">
      {/* рендер графиков */}
    </div>
  );
}
```

Чистый UI-компонент. Нет замка — ИИ может править. Нет финансовой логики — только отрисовка.

**`10300_dashboard_payment.jsx` — форма оплаты (280 строк)**

```jsx
// [IDX: 10300] Форма оплаты дашборда
import { PAYMENT_RATES } from '../capsules/00000-10300-00001_payment_math.json';

export function PaymentForm({ onSubmit }) {
  // UI формы, валидация полей, вызов onSubmit
  // Формулы расчёта НЕ здесь — они в капсуле
  return (
    <div data-idx="10300" data-desc="Форма оплаты">
      {/* инпуты, кнопка */}
    </div>
  );
}
```

**`10400_dashboard_events.jsx` — обработчики (220 строк)**

```jsx
// [IDX: 10400] Обработчики событий дашборда
export function useDashboardEvents(rates) {
  // хуки, обработчики, маппинг данных
  return { chartData, handlePayment };
}
```

**`00000-10300-00001_payment_math.json` — капсула (90 строк)**

```json
{
  "_meta": {
    "idx": "00000-10300-00001",
    "lock": "00000",
    "desc": "Финансовые ставки и формулы — правка запрещена"
  },
  "rates": {
    "default": 0.15,
    "premium": 0.08,
    "wholesale": 0.05
  },
  "formulas": {
    "commission": "amount * rate",
    "total": "amount + amount * rate"
  }
}
```

### Сводка

| | До | После |
|---|---|---|
| Файлов | 1 | 5 (4 рабочих + 1 капсула) |
| Самый длинный файл | 1200 строк | 310 строк |
| Риск паразитной правки | высокий | изолирован замком 00000 |
| Поиск блока | сканирование 1200 строк | прямой адрес по IDX |
| Контекст для ИИ | 1200 строк | ≤ 310 строк на задачу |

### Пример запроса к ИИ

> «В слоте [IDX: 10200] поменяй цвет столбцов на синий»

ИИ открывает только `10200_dashboard_charts.jsx` (310 строк), правит цвет, коммитит. Страж проверяет: коллизий нет, замки не тронуты, лимит в норме. Капсула с формулами даже не открывается.

---

## ❓ FAQ

### Почему именно 400 строк (4 листа А4), а не 200 или 600?

Это эмпирический порог, выведенный из наблюдений за поведением трансформеров:

- **До 400 строк** модель стабильно удерживает начало, середину и конец контекста; риск «потерять» инструкцию остаётся на приемлемом уровне.
- **После 500–600 строк** заметно растёт эффект «lost in the middle»: детали из середины начинают выпадать, инструкции в начале — забываться.
- **200 строк** — слишком жёстко: избыточная фрагментация усложняет навигацию.

Число не магическое, а компромисс. Скрипт-страж использует порог в 450 строк как мягкий сигнал.

### Как мигрировать существующий легаси-проект?

Поэтапно, без остановки разработки:

1. **Инвентаризация:** запустите `build_index.js` — увидите, какие файлы превышают лимит.
2. **Выделение капсул:** вынесите критические блоки в файлы с `00000-`, поставьте `data-lock="00000"`.
3. **Декомпозиция «толстых» файлов:** начните с самых проблемных модулей.
4. **Присвоение IDX:** добавьте `[IDX: XXXXX]` только для блоков, которые правят ИИ-агенты.
5. **Включение стража:** подключите `guard_utyansky_slots.py` в pre-commit.

### Зачем нужны строгие 5-значные числа, а не текстовые слаги?

- **Коллизии имён:** «header», «Header», «main-header» — для ИИ похожие строки, которые легко перепутать.
- **Нестабильность при рефакторинге:** числовой IDX не зависит от имени файла.
- **O(1) поиск:** адрес без сканирования содержимого.
- **Защита от галлюцинаций:** меньше «догадок» — меньше ошибок.

Текстовые слаги остаются в именах файлов для человека. Числовой IDX — координата для ИИ.

### Что делать с огромными файлами, которые сложно разбить?

Три паттерна:

1. **Разделение ответственности:** логика (≤ 400 строк) в рабочем файле, большие структуры — в капсуле `00000-`.
2. **Иерархическая декомпозиция:** разбивайте на подграфы по смысловым зонам, каждый — отдельный слот.
3. **Режим «только чтение»:** пометьте файл как капсулу, правки — через адаптеры.

---

## 📄 Лицензия

MIT — берите, используйте, развивайте. Стандарт открыт.

---

*Автор: Владислав Утянский (AI Architect & Founder)*
*Версия: v2.6 (08.10.2026)*
*Репозиторий: [github.com/vlad-utyansky/utyansky-index](https://github.com/vlad-utyansky/utyansky-index)*
