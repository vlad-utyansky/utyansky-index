// [IDX: 90200] Оркестратор пайплайна
const { routeToAgent } = require('./90100_agent_router.js');

// Симуляция вызова LLM (замените на реальный API-вызов)
async function callLLM(systemPrompt, userContext) {
  return {};
}

// Основной пайплайн
async function runPipeline(taskDescription) {
  const results = [];

  // 1. Планировщик — разбивает ТЗ на задачи
  const plannerCtx = routeToAgent('planner', { description: taskDescription });
  const plan = await callLLM(plannerCtx.systemPrompt, plannerCtx.userContext);
  results.push({ agent: 'planner', output: plan });

  const tasksList = Array.isArray(plan) ? plan : [];

  // 2. Для каждой задачи: Исполнитель -> Валидатор
  for (const task of tasksList) {
    // Исполнитель
    const coderCtx = routeToAgent('coder', { file: task.file, slot: task.slot });
    const codeResult = await callLLM(coderCtx.systemPrompt, coderCtx.userContext);
    results.push({ agent: 'coder', slot: task.slot, output: codeResult });

    // Валидатор
    const validatorCtx = routeToAgent('validator', { file: task.file, slot: task.slot });
    const verdict = await callLLM(validatorCtx.systemPrompt, validatorCtx.userContext);
    results.push({ agent: 'validator', slot: task.slot, output: verdict });

    // Если валидатор не пропустил — останавливаем
    if (verdict && verdict.verdict === 'fail') {
      results.push({ status: 'pipeline_stopped', reason: `Slot ${task.slot} failed validation`, issues: verdict.issues });
      break;
    }
  }

  return results;
}

module.exports = { runPipeline };
