# 🏛️ UtyanskyDevKit · Series 2.7
### Standalone Visual Manipulator, DOM Inspector & Spatial Calibrator for AI Vibe-Coding
**Standard: Utyansky Index Architecture Specification v2.5**  
**Legal Protection: Rospatent (Russian Federation) App. No. 2026603415**  
**Author & Founder: Vladislav Anatolyevich Utyansky (AI Architect & Founder)**  
**Languages: Bilingual (Russian 🇷🇺 / English 🇬🇧)**

[![Version](https://img.shields.io/badge/version-2.7.0-emerald.svg)](package.json)
[![Standard](https://img.shields.io/badge/standard-Utyansky_Index_v2.5-00ff88.svg)](README.md)
[![Rospatent](https://img.shields.io/badge/Rospatent_App-No._2026603415-blue.svg)](LICENSE)
[![Zero Context Loss](https://img.shields.io/badge/AI_VibeCoding-Zero_Context_Loss-indigo.svg)](README.md)
[![License](https://img.shields.io/badge/License-Proprietary-amber.svg)](LICENSE)

---

## 🎬 The Origin Story: Why Vibe Coding Breaks Without Slots
Every developer doing vibe-coding with LLMs (Gemini, Claude, GPT) has faced this agonizing scenario:

1. **The Innocuous Task:** You have a clean layout with a sidebar containing your critical **💳 "Upgrade/Pay"** button. The chat widget is just 20px too high. You prompt: *"Move the chat window slightly lower"*.
2. **The Downward Smash:** The LLM over-corrects, injecting massive margins. The chat crashes into the footer!
3. **The Ceiling Smash:** You ask to raise it. The LLM catapults it into orbit, overlapping the top navigation and logo!
4. **The Silent Disaster (30 min in):** Finally, after 30 minutes of CSS ping-pong, the chat is centered. But you glance at the sidebar in horror: **the LLM quietly erased the "Pay" button!** Monetization destroyed by attention drift.
5. **The Utyansky Index Solution (1 sec):** With deterministic 5-digit slots (`[IDX: 51301]`), the AI targets *only* that component with guaranteed $O(1)$ isolation. Adjacent components are guarded by `[IDX: 00000]`. Zero side effects, zero code casualties.

👉 **Experience the live 5-step interactive story:** Open [`presentation_standalone.html`](presentation_standalone.html) or [`index.html`](index.html) in your browser!

---

## ⚡ 3 Ways to Deploy UtyanskyDevKit:

### 🥇 Method 1: Auto-Install in 1 Command (Recommended)
Run the built-in installer targeting your HTML file:
```bash
node install.js path/to/index.html [base_index]
```
**What the installer does automatically:**
1. Copies `utyansky_devkit.js` into your project directory.
2. Injects `<script src="utyansky_devkit.js"></script>` before `</body>`.
3. Performs 100% DOM indexing with unique 5-digit `data-idx` attributes (no duplicates).

### 🥈 Method 2: Single Script Tag (Zero-Config)
Place `utyansky_devkit.js` in your project folder and add:
```html
<script src="utyansky_devkit.js"></script>
```

### 🥉 Method 3: Download QuickStart Bundle
Download and extract `UtyanskyDevKit_v2.7_QuickStart.zip` for a complete, pre-configured environment.

---

## 🛠️ Package Manifest & Files:

| File | Purpose |
| :--- | :--- |
| **`index.html`** / **`presentation_standalone.html`** | 100% Autonomous, single-file 5-step interactive presentation (67 KB, zero dependencies). |
| **`presentation.html`** | Clean modular presentation (< 400 lines, context-optimized). |
| **`story_data.js`** | Bilingual (RU/EN) data capsule and dynamic Mentor descriptions dictionary. |
| **`demo.html`** | Interactive test playground and clipboard verification harness. |
| **`utyansky_devkit.js`** | Production runtime inspector & dock (IDX, PXL, MNTR, F1, RU/EN). |
| **`utyansky_dom_indexer.js`** | CLI DOM indexer ensuring 100% 5-digit slot coverage. |
| **`install.js`** | One-command installer and DOM auto-injector. |
| **`package.json`** | npm package manifest (`@vau/utyansky-devkit@2.7.0`). |
| **`LICENSE`** | Author & Rospatent application license agreement. |
| **`UtyanskyDevKit_v2.7_QuickStart.zip`** | Standalone zip bundle for GitHub Releases. |

---

## 🎮 Controls & Founder Hotkeys:

| Key / Sequence | Action |
| :--- | :--- |
| **`U`** (Utyansky) | Toggle DevKit dock panel visibility. |
| **`V`** (Vladislav) | Toggle DevKit dock panel visibility. |
| **`V-A-U`** / **`В-А-У`** | Founder secret cheat code (type anywhere on keyboard to awaken dock on production). |
| **`U-V-A`** / **`У-В-А`** | Alternative Founder awakening code. |
| **`F1`** | Interactive on-screen quick reference guide. |
| **`RU / EN`** | Instant bidirectional language toggle for all tooltips, toasts, and guides. |

---

## 📋 How Click-to-Clipboard Works:
1. Click **`[IDX]`** in the dock — elements illuminate in emerald neon `#00ff88`.
2. Left-click any element on the screen.
3. The inspector captures the click, prevents link navigation, copies `[IDX: XXXXX]` to clipboard, and displays a toast notification.
4. Paste the index (`Ctrl + V`) into your AI chat prompt. The LLM targets strictly that slot with 100% precision.
5. Click **`[PXL]`** to toggle the 20x20 laser spatial navigation grid and live X/Y cursor tracking.
6. Click **`[MNTR]`** to activate architecture insights and element role descriptions.

---

## ⚖️ Legal & Intellectual Property Notice
Standard: **Utyansky Index Architecture Specification v2.5**  
Rospatent (Russian Federation) Patent Application No. **2026603415**  
Author & Copyright: **Vladislav Anatolyevich Utyansky (VAU EFFECT, 2026)**  
Official Portal: [https://vau.ru](https://vau.ru)
