# 🏛️ UtyanskyDevKit · Series 2.6.8
### Standalone Visual Manipulator, DOM Inspector & Spatial Calibrator for AI Vibe-Coding
**Standard: Utyansky Index Architecture Specification v2.5**  
**Legal Protection: Rospatent (Russian Federation) App. No. 2026603415**  
**Author & Founder: Vladislav Anatolyevich Utyansky (AI Architect & Founder)**  
**Languages: Bilingual (Russian 🇷🇺 / English 🇬🇧)**

[![Version](https://img.shields.io/badge/version-2.6.8-emerald.svg)](package.json)
[![Standard](https://img.shields.io/badge/standard-Utyansky_Index_v2.5-00ff88.svg)](README.md)
[![Rospatent](https://img.shields.io/badge/Rospatent_App-No._2026603415-blue.svg)](LICENSE)
[![Zero Context Loss](https://img.shields.io/badge/AI_VibeCoding-Zero_Context_Loss-indigo.svg)](README.md)
[![License](https://img.shields.io/badge/License-Proprietary-amber.svg)](LICENSE)

---

## 🇷🇺 Русская версия: История создания и руководство

# 🏛️ Как я устал от капризов нейросетей и создал UtyanskyDevKit
### История о том, как одна стёртая кнопка «Оплатить» изменила мой подход к вайб-кодингу
**Автор:** Владислав Утянский (Founder & Chief AI Architect)  
**Боевая практика:** Февраль 2026 — Октябрь 2026 (8+ месяцев ежедневного кодинга с LLM)

---

### «Вайб-кодинг — это сказка... пока ты не нажмешь F5»

В феврале 2026 года, как и многие, я был в полном восторге от возможностей больших языковых моделей. Казалось, будущее уже наступило: формулируешь мысль, нейросеть за секунды набрасывает интерфейс, и ты летишь вперед.

Но эйфория быстро разбилась о суровую реальность фронтенда.

Каждый, кто пробовал писать интерфейсы в связке с Claude, GPT или Gemini, наверняка проживал этот кошмар:
1. У тебя готов аккуратный интерфейс. В сайдбаре висит критически важная для проекта кнопка **«💳 Оплатить подписку»**. Всё работает. Но вот плашка чата поддержки съехала на 20 пикселей выше, чем нужно.
2. Ты спокойно пишешь модели: *«Подвинь чат чуть ниже»*.
3. Модель бодро рапортует: *«Готово, я всё исправила!»*. Обновляешь страницу — плашка чата с грохотом пробивает разметку и улетает в футер.
4. Пишешь: *«Нет, верни повыше»*. Модель катапультирует её в космос, перекрывая верхнее меню и логотип.
5. Начинается изнурительный **30-минутный CSS-пинг-понг**. Тратятся нервы, сжигаются токены, пробуются разные слова и промпты.
6. Наконец, чат встал ровно по центру. Ты с облегчением выдыхаешь... переводишь взгляд в сайдбар и холодеешь:
   **Кнопки «Оплатить» больше нет.**

Модель просто тихо стёрла её. В процессе переписывания стилей она посчитала кнопку лишней. Монетизация проекта уничтожена, а ты сидишь и вручную копаешься в `git diff`, пытаясь спасти пропавший код.

---

### Поиски в сети: Пустота

Когда это повторилось в третий раз за неделю, моей первой мыслью было: *«Не может быть, чтобы в мире никто с этим не столкнулся. Наверняка на GitHub уже есть готовое решение, библиотека или расширение для браузера»*.

Я перерыл весь интернет, форумы разработчиков, сообщества по вайб-кодингу. **Ничего.** 
Везде предлагали одно и то же: *«пишите более подробные промпты»* или *«скармливайте модели скриншоты экрана»*. Но скриншоты только путали модель, а длинные промпты забивали контекст, и нейросеть начинала тупить ещё сильнее.

Решения в природе просто не существовало. И тогда я понял: если хочу нормально работать, придётся разрабатывать его с нуля своими руками.

---

### Почему нейросети «слепнут» в браузере?

Причина их поведения оказалась простой: **у языковых моделей нет пространственного зрения в DOM-дереве**.
Для LLM ваш красивый сайт — это просто серая простыня текста из сотен повторяющихся тегов `<div>`, `<button>` и бесконечных классов. Когда вы говорите модели: *«подвинь ту плашку справа»*, у неё начинается расфокус внимания. Она не видит экран, она лишь гадает вероятности следующих токенов.

Идея заключалась в том, чтобы **придать абсолютно каждому элементу в системе свой собственный уникальный номер** — словно почтовый индекс или персональные GPS-координаты. И тогда модели не нужно гадать, о какой именно «плашке» или «кнопке» идёт речь: она мгновенно находит в коде точную координату и работает только с ней, физически не имея права трогать соседние блоки.

---

### От простого «Дева» к эволюции системы

То, что задумывалось как простой наколеночный скрипт («Дев») для решения одной наболевшей проблемы, в итоге стало постоянно развиваться и эволюционировать дальше. 

Каждый день практики подкидывал новые нюансы:
* Сначала я просто встроил в браузер парящую кнопку, которая по клику подсвечивала блоки и копировала их номера. 
* Потом понял, что модели нужен не абстрактный класс, а строгий числовой слот `[IDX: 51301]`. Кликнул по блоку на экране ➔ нажал `Ctrl + V` в чате с ИИ ➔ модель за 1 секунду правит ровно эти 5 строк, не смея трогать соседей.
* Затем в реальной верстке потребовалось двигать элементы без постоянного открытия громоздких DevTools — так появилась лазерная пространственная сетка 20×20 **`[PXL]`** с живыми координатами курсора.
* Потом понадобилось объяснять архитектуру чужим или новым моделям — появился модуль Ментора **`[MNTR]`** и мгновенный переключатель **`RU / EN`**.

Инструмент рос органически, потому что каждый его элемент был выстрадан на живой практике, а не придуман за столом.

---

### 8 месяцев проверки боем

С февраля по октябрь 2026 года — 8+ месяцев ежедневного кодинга — я работал исключительно через этот пульт:
* **Ноль** случайно стёртых кнопок и сломанных соседних блоков.
* Расход токенов упал в разы, потому что модель больше не переписывает страницу целиком ради одного отступа.
* Исправление любого визуального элемента занимает ровно 3 секунды: **Клик ➔ Вставить слот ➔ Готово**.

---

### Открытый доступ

Сегодня вайб-кодинг часто преподносят как магию. Но любой, кто делает реальные проекты, знает: без четких ориентиров эта магия быстро превращается в хаос.

Я выкладываю **UtyanskyDevKit** в открытый доступ, чтобы любой разработчик — от соло-фаундера до тимлида — мог подключить его к своему проекту одной строчкой:
```html
<script src="utyansky_devkit.js"></script>
```
...и навсегда забыть про исчезающие кнопки, CSS-пинг-понг и впустую потраченные часы.

👉 **Интерактивная презентация:** Запустите [`presentation_standalone.html`](presentation_standalone.html) или [`index.html`](index.html) прямо в браузере, чтобы вживую покликать историю!

---

## ⚡ 3 способа быстрого подключения UtyanskyDevKit:

### 🥇 Способ 1: Авто-установка в 1 команду (Рекомендуется)
Запустите встроенный установщик, указав путь к вашему HTML-файлу:
```bash
node install.js path/to/index.html [base_index]
```
**Что установщик сделает автоматически:**
1. Скопирует `utyansky_devkit.js` в директорию вашего проекта;
2. Вставит `<script src="utyansky_devkit.js"></script>` перед закрывающим тегом `</body>`;
3. Выполнит 100% разметку DOM уникальными 5-значными атрибутами `data-idx` без дубликатов.

### 🥈 Способ 2: Один тег `<script>` (Zero-Config)
Положите `utyansky_devkit.js` в папку с проектом и добавьте в HTML:
```html
<script src="utyansky_devkit.js"></script>
```

### 🥉 Способ 3: Скачать QuickStart Архив
Скачайте готовый архив `UtyanskyDevKit_v2.7_QuickStart.zip` со всеми примерами и демо-стендом.

---

## 🎮 Управление:

* **`VAU` / `ВАУ`** (просто наберите на клавиатуре в любом месте страницы) — моментально показать или скрыть панель DevKit.
* **`F1`** — интерактивная справка прямо в интерфейсе.
* **`RU / EN`** — мгновенное переключение языка подсказок и Ментора.

---

## 📋 Как работает «Захват слота в буфер» (Click-to-Clipboard):
1. Нажмите кнопку **`[IDX]`** на парящей панели — элементы подсветятся неоновым изумрудным цветом `#00ff88`.
2. Кликните левой кнопкой мыши по любому элементу на экране.
3. Инспектор перехватит клик (блокируя случайный переход по ссылкам), скопирует точный слот `[IDX: XXXXX]` в буфер обмена и покажет всплывающее уведомление.
4. Вставьте индекс (`Ctrl + V`) в чат с нейросетью. LLM точечно найдёт именно этот блок со 100% точностью.
5. Нажмите **`[PXL]`**, чтобы включить пространственную калибровочную сетку 20×20 и трекинг координат мыши.
6. Нажмите **`[MNTR]`**, чтобы включить архитектурного Ментора с пояснениями ролей блоков.

---
---

## 🇬🇧 English Version: The Origin Story & Architecture

## 🎬 The Origin Story: Why Vibe Coding Breaks Without Slots
Every developer doing vibe-coding with LLMs (Gemini, Claude, GPT) has faced this agonizing scenario:

1. **The Innocuous Task:** You have a clean layout with a sidebar containing your critical **💳 "Upgrade/Pay"** button. The chat widget is just 20px too high. You prompt: *"Move the chat window slightly lower"*.
2. **The Downward Smash:** The LLM over-corrects, injecting massive margins. The chat crashes into the footer!
3. **The Ceiling Smash:** You ask to raise it. The LLM catapults it into orbit, overlapping the top navigation and logo!
4. **The Silent Disaster (30 min in):** Finally, after 30 minutes of CSS ping-pong, the chat is centered. But you glance at the sidebar in horror: **the LLM quietly erased the "Pay" button!** Monetization destroyed by attention drift.
5. **The Search for a Solution:** Looking across GitHub and forums revealed absolute emptiness — no tool connected browser clicks with precise LLM token targeting.
6. **The Utyansky Index Solution:** By assigning each element an immutable 5-digit coordinate slot (`[IDX: 51301]`), the AI targets *strictly* that component with guaranteed $O(1)$ isolation. Adjacent components are guarded by `[IDX: 00000]`. Zero side effects, zero code casualties.

👉 **Experience the live 5-step interactive story:** Open [`presentation_standalone.html`](presentation_standalone.html) or [`index.html`](index.html) in your browser!

---

## 🛠️ Package Manifest & Files:

| File | Purpose |
| :--- | :--- |
| **`index.html`** / **`presentation_standalone.html`** | 100% Autonomous, single-file 5-step interactive presentation (67 KB, zero dependencies). |
| **`presentation.html`** | Clean modular presentation (< 400 lines, context-optimized). |
| **`story_data.js`** | Bilingual (RU/EN) data capsule and dynamic Mentor descriptions dictionary. |
| **`demo.html`** | Interactive test playground and clipboard verification harness. |
| **`utyansky_devkit.js`** | Production runtime inspector & dock (IDX, PXL, MNTR, F1, RU/EN). |
| **`utyansky_dom_indexer.js`** | CLI DOM indexer ensuring 100% 5-digit slot coverage. |
| **`install.js`** | One-command installer and DOM auto-injector. |
| **`package.json`** | npm package manifest (`@vau/utyansky-devkit@2.7.0`). |
| **`LICENSE`** | Author & Rospatent application license agreement. |
| **`UtyanskyDevKit_v2.7_QuickStart.zip`** | Standalone zip bundle for GitHub Releases. |

---

## ⚖️ Legal & Intellectual Property Notice
Standard: **Utyansky Index Architecture Specification v2.5**  
Rospatent (Russian Federation) Patent Application No. **2026603415**  
Author & Copyright: **Vladislav Anatolyevich Utyansky (VAU EFFECT, 2026)**  
Official Portal: [https://vau.ru](https://vau.ru)
