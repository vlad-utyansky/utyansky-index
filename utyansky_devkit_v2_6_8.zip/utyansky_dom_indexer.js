#!/usr/bin/env node
/**
 * 🏛️ [IDX: 00000-75000-00001] ЭТАЛОННЫЙ АВТО-ИНДЕКСАТОР DOM ИНДЕКСА УТЯНСКОГО
 * Стандарт: Индекс Утянского (Заявка Роспатент РФ № 2026603415)
 * Назначение: 100% тотальная оцифровка любого HTML/JSX файла без пропусков и дубликатов.
 * 
 * Использование:
 *   node scripts/utyansky_dom_indexer.js <путь_к_файлу.html> [базовый_индекс]
 * 
 * Пример:
 *   node scripts/utyansky_dom_indexer.js "22_Сборка.../index.html" 75001
 *   node scripts/utyansky_dom_indexer.js "23_Сборка.../v-matrix-1973.html" 77001
 */

const fs = require('fs');
const path = require('path');

const targetFile = process.argv[2];
const baseIndexArg = process.argv[3] ? parseInt(process.argv[3], 10) : 75001;

if (!targetFile || !fs.existsSync(targetFile)) {
  console.error('❌ Ошибка: Укажите корректный путь к HTML файлу.');
  console.log('Использование: node scripts/utyansky_dom_indexer.js <файл.html> [базовый_индекс]');
  process.exit(1);
}

console.log(`\n======================================================`);
console.log(`🏛️ ИНДЕКС УТЯНСКОГО: ТОТАЛЬНАЯ КАЛИБРОВКА DOM`);
console.log(`Файл: ${path.resolve(targetFile)}`);
console.log(`Базовый индекс: ${baseIndexArg}`);
console.log(`======================================================\n`);

let html = fs.readFileSync(targetFile, 'utf8');

// Служебные и невидимые теги, которые никогда не индексируются
const IGNORE_TAGS = new Set([
  'html', 'head', 'meta', 'title', 'link', 'script', 'style', 'base',
  'br', 'hr', 'wbr', 'svg', 'path', 'circle', 'line', 'polygon', 'polyline',
  'rect', 'defs', 'clippath', 'use', 'g'
]);

// 1. Сбор существующих индексов
const existingMatches = html.match(/data-idx="([^"]+)"/g) || [];
const usedSet = new Set();
const allNumbers = [];

existingMatches.forEach(m => {
  const val = m.match(/data-idx="([^"]+)"/)[1];
  usedSet.add(val);
  if (/^\d+$/.test(val)) {
    allNumbers.push(parseInt(val, 10));
  }
});

let nextIdx = allNumbers.length > 0 ? Math.max(...allNumbers, baseIndexArg) + 1 : baseIndexArg;

function getNextUniqueIdx() {
  while (usedSet.has(String(nextIdx))) {
    nextIdx++;
  }
  const assigned = String(nextIdx++);
  usedSet.add(assigned);
  return assigned;
}

// 2. Семантический генератор data-desc по атрибутам тега
function generateDesc(tagName, attrs) {
  let type = tagName.toUpperCase();
  let name = '';

  const idMatch = attrs.match(/id="([^"]+)"/i);
  if (idMatch) name = idMatch[1];

  const i18nMatch = attrs.match(/data-i18n="([^"]+)"/i);
  if (i18nMatch) name = (name ? name + ' · ' : '') + i18nMatch[1];

  const titleMatch = attrs.match(/title="([^"]+)"/i);
  if (!name && titleMatch) name = titleMatch[1];

  const placeholderMatch = attrs.match(/placeholder="([^"]+)"/i);
  if (!name && placeholderMatch) name = placeholderMatch[1];

  if (!name) {
    const classMatch = attrs.match(/class="([^"]+)"/i);
    if (classMatch) {
      const cls = classMatch[1].split(/\s+/)
        .filter(c => !c.startsWith('dark:') && !c.includes('[') && !c.includes(':') && c.length > 2)
        .slice(0, 2)
        .join(' ');
      name = cls || tagName;
    } else {
      name = tagName;
    }
  }

  name = name.replace(/"/g, '').substring(0, 60);
  return `[${type}] ${name}`;
}

let newlyIndexed = 0;

// 3. Проход 1: Простановка недостающих индексов на все теги DOM
html = html.replace(/<([a-zA-Z0-9\-]+)([^>]*)>/g, (fullMatch, tagName, attrs) => {
  const tLower = tagName.toLowerCase();
  if (IGNORE_TAGS.has(tLower)) return fullMatch;
  if (attrs.trim().endsWith('/')) return fullMatch; // Самозакрывающийся XML-тег
  if (/data-idx=/i.test(attrs)) return fullMatch; // Уже имеет индекс

  const idx = getNextUniqueIdx();
  const desc = generateDesc(tagName, attrs);
  newlyIndexed++;
  return `<${tagName} data-idx="${idx}" data-desc="${desc}"${attrs}>`;
});

// 4. Проход 2: Дедупликация (устранение любых возможных случайных дублей)
const seen = new Set();
let dupesFixed = 0;

html = html.replace(/data-idx="([^"]+)"/g, (fullMatch, idxVal) => {
  if (!seen.has(idxVal)) {
    seen.add(idxVal);
    return fullMatch;
  } else {
    const freshIdx = getNextUniqueIdx();
    dupesFixed++;
    return `data-idx="${freshIdx}"`;
  }
});

// 5. Проход 3: Очистка суффиксов версий (Строгое табу Конституции)
html = html.replace(/v2\.6\.3/g, '');
html = html.replace(/v2\.6/g, '');
html = html.replace(/v2\.5/g, '');
html = html.replace(/v2\.0/g, '');

// 6. Сохранение результата
fs.writeFileSync(targetFile, html, 'utf8');

// 7. Контрольная верификация
const finalMatches = html.match(/data-idx="([^"]+)"/g) || [];
const finalCounts = {};
let finalDupes = 0;
let nonNumeric = 0;

finalMatches.forEach(m => {
  const v = m.match(/data-idx="([^"]+)"/)[1];
  finalCounts[v] = (finalCounts[v] || 0) + 1;
  if (finalCounts[v] > 1) finalDupes++;
  if (!/^\d+(-\d+)*$/.test(v)) nonNumeric++;
});

console.log(`✅ Новых проиндексированных узлов: ${newlyIndexed}`);
console.log(`✅ Устранено дубликатов: ${dupesFixed}`);
console.log(`✅ Всего узлов под замком [IDX]: ${finalMatches.length}`);
console.log(`✅ Дубликатов осталось: ${finalDupes}`);
console.log(`✅ Нарушений числового формата: ${nonNumeric}`);

if (finalDupes === 0 && nonNumeric === 0) {
  console.log(`\n🎉 СТАТУС: 100% ВАЛИДАЦИЯ ПРОЙДЕНА! Файл полностью откалиброван.\n`);
} else {
  console.warn(`\n⚠️ Внимание: Требуется повторная проверка.\n`);
}
