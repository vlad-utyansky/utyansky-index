// [IDX: 51000-00001] Данные и двуязычные тексты интерактивной презентации Индекса Утянского
window.STEPS_DATA = [
  {
    step: 1,
    time: '14:00',
    badge: { ru: 'Шаг 1 из 5 · Обычный день', en: 'Step 1 of 5 · A Normal Day' },
    title: { ru: '«Сдвинь окно чата чуть-чуть ниже...»', en: '“Move the chat window slightly lower...”' },
    story: {
      ru: 'Красивый интерфейс: шапка, левый сайдбар с яркой кнопкой <b>«💳 Оплатить тариф»</b>, окно чата. Но окно визуально задрано слишком высоко. Разработчик просит ИИ: <i>«Сдвинь окно чата чуть ниже на пару сантиметров»</i>.',
      en: 'Clean layout: top bar, left sidebar with prominent <b>“💳 Upgrade/Pay”</b> button, chat widget. But chat sits visibly too high. Founder asks AI: <i>“Shift the chat window a bit lower, by a couple of centimeters”</i>.'
    },
    prompt: {
      ru: '«Окно чата висит слишком высоко. Сдвинь его чуть-чуть ниже, пожалуйста.»',
      en: '“The chat window sits too high. Shift it slightly lower, please.”'
    },
    response: {
      ru: '«Принято! Обновляю CSS-стили позиционирования контейнера чата...»',
      en: '“Got it! Updating CSS positioning styles of the chat container...”'
    },
    alert: {
      type: 'info',
      ru: 'ℹ️ <b>Ожидание:</b> деликатный сдвиг вниз на 20px. <b>Реальность:</b> старт 30-минутного кошмара.',
      en: 'ℹ️ <b>Expectation:</b> clean 20px nudge. <b>Reality:</b> start of a 30-minute prompt nightmare.'
    },
    chatPos: { top: '15px', left: '40px', border: 'border-slate-300 dark:border-slate-700' },
    coords: 'top: 15px (слишком высоко)',
    hasPayBtn: true,
    slotStatus: { ru: 'Слоты: Не защищены', en: 'Slots: Unprotected' }
  },
  {
    step: 2,
    time: '14:08',
    badge: { ru: 'Шаг 2 из 5 · Удар в пол', en: 'Step 2 of 5 · Downward Smash' },
    title: { ru: 'ИИ швыряет окно в самый подвал страницы', en: 'AI catapults the window to the absolute bottom' },
    story: {
      ru: 'Модель восприняла команду «ниже» буквально. Вместо деликатного сдвига она прописала огромный отступ. Чат рухнул в самый низ, перекрыл разметку и прилип к нижнему футеру!',
      en: 'The LLM took “lower” literally. Instead of 20px, it injected massive margin. The chat crashed to the very bottom, overlapping the layout and sticking to the footer!'
    },
    prompt: {
      ru: '«Куда ты его унесла?! Окно улетело в самый низ экрана! Подними чуть выше!»',
      en: '“Where did you throw it?! It crashed to the bottom! Raise it slightly!”'
    },
    response: {
      ru: '«Прошу прощения за ошибку! Поднимаю позицию окна чата наверх...»',
      en: '“Apologies for the mistake! Raising the chat window position up...”'
    },
    alert: {
      type: 'warning',
      ru: '⚠️ <b>Пинг-понг 1:</b> Чат в подвале. Разметка сломана. Начинается раздражение.',
      en: '⚠️ <b>Ping-Pong 1:</b> Chat crashed at bottom. Layout broken. Frustration begins.'
    },
    chatPos: { top: '340px', left: '40px', border: 'border-amber-400 dark:border-amber-500' },
    coords: 'top: 340px (удар в подвал)',
    hasPayBtn: true,
    slotStatus: { ru: 'Слоты: Мутация стилей', en: 'Slots: Style Mutation' }
  },
  {
    step: 3,
    time: '14:18',
    badge: { ru: 'Шаг 3 из 5 · Удар в потолок', en: 'Step 3 of 5 · Ceiling Smash' },
    title: { ru: 'ИИ закидывает чат наверх, ломая шапку', en: 'AI hurls the chat into the header bar' },
    story: {
      ru: 'В ответ на «подними чуть выше» нейросеть снова мажет! Окно чата улетело под самый верх и физически перекрыло шапку сайта, логотип и поиск. Идёт уже 20-я минута бессмысленной перепалки с моделью.',
      en: 'In response to “raise slightly”, the AI overshoots again! The chat shot straight into the ceiling, overlapping the header, logo and search. 20 minutes wasted arguing with the model.'
    },
    prompt: {
      ru: '«Нет! Не настолько высоко! Поставь ровно по центру рабочего экрана!»',
      en: '“No! Not that high! Place it exactly in the vertical center of the workspace!”'
    },
    response: {
      ru: '«Понял! Полностью переписываю родительский контейнер с flexbox для центрирования...»',
      en: '“Understood! Completely refactoring parent container with flexbox to center...”'
    },
    alert: {
      type: 'danger',
      ru: '🚨 <b>Пинг-понг 2:</b> Коллизия с навигацией. Модель решает переписать весь родительский код!',
      en: '🚨 <b>Ping-Pong 2:</b> Header collision. AI decides to rewrite full parent template!'
    },
    chatPos: { top: '-25px', left: '40px', border: 'border-red-400 dark:border-red-500' },
    coords: 'top: -25px (коллизия с шапкой)',
    hasPayBtn: true,
    slotStatus: { ru: 'Слоты: Угроза деградации', en: 'Slots: Degradation Danger' }
  },
  {
    step: 4,
    time: '14:32',
    badge: { ru: 'Шаг 4 из 5 · Драма и Катастрофа', en: 'Step 4 of 5 · The Silent Disaster' },
    title: { ru: 'Чат по центру. Но кнопка «Оплатить» стёрта!', en: 'Chat is centered. But “Pay” button is GONE!' },
    story: {
      ru: '30 минут уговоров! Чат наконец-то встал ровно по центру. Казалось бы, победа? Нет! Разработчик смотрит в меню и холодеет: переписывая HTML-родителя, <b>модель бесследно СТЁРЛА кнопку «💳 Оплатить тариф»!</b> Главный компонент выручки стёрт из-за утечки контекста.',
      en: '30 minutes of ping-pong! Chat is finally centered. Victory? No! Founder glances at the sidebar and freezes: while re-rendering HTML, <b>the AI quietly DELETED the “💳 Upgrade/Pay” button!</b> Monetization wiped out by LLM context degradation.'
    },
    prompt: {
      ru: '«Стой... А где кнопка оплаты в сайдбаре?! Ты стёрла 30 строк кода монетизации!»',
      en: '“Wait... where is the Pay button in the sidebar?! You wiped out 30 lines of billing code!”'
    },
    response: {
      ru: '«Прошу прощения, при обновлении разметки блок кнопки был случайно опущен...»',
      en: '“Apologies, while re-writing the container markup the button block was omitted...”'
    },
    alert: {
      type: 'danger',
      ru: '💀 <b>Тихая гибель кода:</b> ИИ не помнит toàn разметку при больших правках. Потеря денег и времени.',
      en: '💀 <b>Silent Code Death:</b> LLMs bleed attention on wide refactors. Lost revenue and lost hours.'
    },
    chatPos: { top: '110px', left: '40px', border: 'border-amber-500 dark:border-amber-400' },
    coords: 'top: 110px (по центру, НО кнопка снесена!)',
    hasPayBtn: false,
    slotStatus: { ru: 'Слоты: КОД ЗАТЁРТ МОДЕЛЬЮ!', en: 'Slots: CODE SILENTLY WIPED!' }
  },
  {
    step: 5,
    time: '14:35',
    badge: { ru: 'Шаг 5 из 5 · Триумф Стандарта', en: 'Step 5 of 5 · Standard Triumph' },
    title: { ru: 'Изоляция O(1) и боевой UtyanskyDevKit', en: 'O(1) Slot Isolation & Live UtyanskyDevKit' },
    story: {
      ru: 'Идеальный результат за 1 секунду! Чат по центру, кнопка оплаты защищена замком <code>[IDX: 00000]</code>. Внизу подключен живой <b>UtyanskyDevKit</b>! Нажмите кнопку <b>[IDX]</b> или <b>[PXL]</b> в доке внизу справа прямо сейчас — испытайте неон и клик-копирование!',
      en: 'Pixel-perfect precision in 1 second! Chat is centered, Pay button locked by <code>[IDX: 00000]</code>. Below sits the live <b>UtyanskyDevKit</b>! Click <b>[IDX]</b> or <b>[PXL]</b> in the dock at bottom-right right now — experience glowing slots and click-to-clipboard!'
    },
    prompt: {
      ru: '«[IDX: 51301] установи top: 110px. Соседние блоки и сайдбар [IDX: 51201] не трогать.»',
      en: '“[IDX: 51301] set top: 110px. Do not touch adjacent blocks or sidebar [IDX: 51201].”'
    },
    response: {
      ru: '«Выполнено за 0.8с! Точечно обновлен слот [IDX: 51301]. 100% изоляция кода.»',
      en: '“Done in 0.8s! Strictly targeted slot [IDX: 51301]. 100% code isolation guaranteed.”'
    },
    alert: {
      type: 'success',
      ru: '⚡ <b>Победа Индекса Утянского:</b> Вместо 30 минут ругани — 1 секунда, 0 побочных эффектов, чистый контекст.',
      en: '⚡ <b>Utyansky Index Triumph:</b> Instead of 30 minutes of ping-pong — 1 second, zero side effects.'
    },
    chatPos: { top: '110px', left: '40px', border: 'border-emerald-500 shadow-[0_0_25px_rgba(0,255,136,0.3)]' },
    coords: 'top: 110px · [IDX: 51301] ОПЕРАЦИЯ O(1)',
    hasPayBtn: true,
    slotStatus: { ru: 'Слоты: [IDX: 51000] ЗАЩИЩЕНО', en: 'Slots: [IDX: 51000] PROTECTED' }
  }
];

window.ELEMENT_DESCRIPTIONS = {
  '51001': { ru: 'Шапка интерактивной презентации Utyansky DevKit', en: 'Utyansky DevKit Interactive Presentation Header' },
  '51002': { ru: 'Навигация по 5 шагам драмы вайбкодинга', en: '5-Step Vibe Coding Drama Navigation Bar' },
  '51003': { ru: 'Главная рабочая область презентации', en: 'Main Presentation Stage Container' },
  '51010': { ru: 'Колонка истории и диалога с ИИ', en: 'AI Prompt Dialogue & Story Column' },
  '51015': { ru: 'Окно симуляции промпт-инжиниринга', en: 'Prompt Engineering Simulation Box' },
  '51020': { ru: 'Холст демонстрационного интерфейса', en: 'Interactive Demo Interface Canvas' },
  '51100': { ru: 'Шапка симуляции рабочего интерфейса', en: 'App Shell Window Titlebar' },
  '51101': { ru: 'Верхняя навигация продукта VAU', en: 'VAU Product Top Navigation Bar' },
  '51201': { ru: 'Боковое меню навигации CRM', en: 'CRM Sidebar Navigation' },
  '51202': { ru: 'Пункт меню: Аналитика', en: 'Menu Item: Analytics' },
  '51203': { ru: 'Пункт меню: Проекты', en: 'Menu Item: Projects' },
  '51204': { ru: 'Пункт меню: Настройки', en: 'Menu Item: Settings' },
  '51205': { ru: 'Кнопка конверсии: Оплатить тариф PRO', en: 'Conversion CTA: Upgrade to Pro Plan' },
  '51300': { ru: 'Главный рабочий холст виджета чата', en: 'Main Chat Widget Canvas Host' },
  '51301': { ru: 'Окно диалога ассистента Cloe AI', en: 'Cloe AI Assistant Dialog Window' },
  '51302': { ru: 'Шапка чата с ассистентом', en: 'Assistant Chat Header Bar' },
  '51303': { ru: 'Тело переписки чата', en: 'Chat Message Thread History' },
  '51304': { ru: 'Поле ввода сообщения чата', en: 'Chat Prompt Input Area' },
  '51401': { ru: 'Нижний статус-бар приложения', en: 'Application Bottom Status Bar' },
  '51500': { ru: 'Подсказка включения виджета DevKit', en: 'DevKit Widget Activation Spotlight' }
};
