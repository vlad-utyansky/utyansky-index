// [IDX: 00000-75000-00002] Установщик быстрого развертывания UtyanskyDevKit Серия 2.7
// Стандарт: Индекс Утянского (Заявка Роспатент РФ № 2026603415)
// Автор: Владислав Анатольевич Утянский
// Назначение: Автоматическая установка "из коробки" в любой веб-проект за 1 команду:
//   1. Копирует utyansky_devkit.js в целевой проект.
//   2. Внедряет <script src="utyansky_devkit.js"></script> перед </body>.
//   3. Проводит 100% авто-индексацию DOM уникальными 5-значными индексами без дубликатов.
// Использование:
//   node scripts/install_utyansky_devkit.js <путь_к_файлу.html> [базовый_индекс]

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const targetPath = process.argv[2] || 'index.html';
const baseIdx = parseInt(process.argv[3], 10) || 71000;

console.log('\n======================================================================');
console.log('🏛️ UTYANSKY DEVKIT · СИСТЕМА БЫСТРОГО РАЗВЕРТЫВАНИЯ ИЗ КОРОБКИ');
console.log('Стандарт «Индекс Утянского» (Роспатент № 2026603415) · Серия 2.7');
console.log('======================================================================\n');

if (!fs.existsSync(targetPath)) {
  console.error(`❌ Ошибка: Целевой файл не найден: "${targetPath}"`);
  console.log('👉 Пример запуска: node scripts/install_utyansky_devkit.js path/to/index.html 71000\n');
  process.exit(1);
}

const targetDir = path.dirname(path.resolve(targetPath));
const devkitSrc = path.join(__dirname, 'utyansky_devkit.js');
const devkitDst = path.join(targetDir, 'utyansky_devkit.js');

// 1. Копирование скрипта UtyanskyDevKit
try {
  if (fs.existsSync(devkitSrc)) {
    fs.copyFileSync(devkitSrc, devkitDst);
    console.log(`✅ [1/3] Модуль utyansky_devkit.js скопирован в: ${devkitDst}`);
  } else {
    // Резервный поиск из папки 51
    const altSrc = path.join(__dirname, '../51_Utyansky_DevKit_Visual_Manipulator_v2.7/utyansky_devkit.js');
    if (fs.existsSync(altSrc)) {
      fs.copyFileSync(altSrc, devkitDst);
      console.log(`✅ [1/3] Модуль utyansky_devkit.js скопирован в: ${devkitDst}`);
    } else {
      console.warn(`⚠️ Внимание: Исходный utyansky_devkit.js не найден рядом со скриптом.`);
    }
  }
} catch(e) {
  console.error(`❌ Ошибка при копировании скрипта:`, e.message);
}

// 2. Внедрение тега подключения в HTML
let html = fs.readFileSync(targetPath, 'utf8');
const scriptTag = '<script src="utyansky_devkit.js"></script>';

if (html.includes('utyansky_devkit.js')) {
  console.log(`ℹ️ [2/3] Тег подключения utyansky_devkit.js уже присутствует в HTML.`);
} else {
  if (html.includes('</body>')) {
    html = html.replace('</body>', `  ${scriptTag}\n</body>`);
  } else {
    html += `\n${scriptTag}\n`;
  }
  fs.writeFileSync(targetPath, html, 'utf8');
  console.log(`✅ [2/3] Тег ${scriptTag} успешно внедрен перед </body>.`);
}

// 3. Автоматическая 100% индексация DOM
const indexerScript = path.join(__dirname, 'utyansky_dom_indexer.js');
if (fs.existsSync(indexerScript)) {
  console.log(`🔄 [3/3] Запуск автоматической индексации DOM (базовый индекс: ${baseIdx})...`);
  try {
    const res = execSync(`node "${indexerScript}" "${targetPath}" ${baseIdx}`, { encoding: 'utf8' });
    console.log(res);
  } catch(err) {
    console.log(`⚠️ Предупреждение при авто-индексации:`, err.message);
  }
} else {
  console.log(`ℹ️ [3/3] Файл utyansky_dom_indexer.js не найден, шаг индексации пропущен.`);
}

console.log('======================================================================');
console.log('🎉 ГОТОВО! UtyanskyDevKit Серия 2.7 успешно развернут из коробки.');
console.log('👉 Откройте страницу в браузере:');
console.log('   - Нажмите [U] или [V] для вызова панели.');
console.log('   - Нажмите [F1] для интерактивной справки.');
console.log('   - Наберите слово VAU на клавиатуре для пробуждения.');
console.log('======================================================================\n');
