# Utyansky Index — Starter Kit

Минимальный скелет проекта по стандарту Индекса Утянского v2.5.

## Структура

```
utyansky-starter-kit/
  src/
    10000_app.jsx                    — корневой оркестратор (замок 00000)
    10100_widget.jsx                  — рабочий UI-компонент (без замка)
  capsules/
    00000-30000-00001_core.json       — капсула критического ядра (замок 00000)
  scripts/
    build_index.js                    — генератор реестра слотов
    guard_utyansky_slots.py           — страж архитектуры (pre-commit)
  hooks/
    pre-commit                        — git hook
```

## Запуск

```bash
# Установить pre-commit hook
cp hooks/pre-commit .git/hooks/pre-commit
chmod +x .git/hooks/pre-commit

# Проверить вручную
python scripts/guard_utyansky_slots.py

# Сгенерировать реестр
node scripts/build_index.js
```

## Три правила

1. **Лимит 400 строк** — любой файл не более ~350–400 строк. Больше — декомпозиция.
2. **Числовой IDX** — каждый блок имеет [IDX: XXXXX]. ИИ правит только по адресу.
3. **Zero-Trust замок** — отлаженные блоки и капсулы помечены data-lock="00000". ИИ их не трогает.
